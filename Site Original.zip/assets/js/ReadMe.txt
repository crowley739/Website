bootstrap.js - Bootstrap Framework // http://getbootstrap.com/

initmap.min.js - Google Maps // http://jeromesmadja.github.io/initmapjs/

jquery.knob.js - plugin for view our skills // http://anthonyterrien.com/knob/

jquery.mixitup.js - MixItUp is a jQuery plugin providing animated filtering and sorting // http://mixitup.io

jquery.nav.js - plugin for navbar // https://github.com/davist11/jQuery-One-Page-Nav

modalEffects.js - nice modal windows // https://github.com/codrops/ModalWindowEffects/tree/master/js

classie.js - helper plugin for classies // https://github.com/ded/bonzo (this plugin is used by modalEffects.js - modal window)

cssParser.js - (this plugin is used by modalEffects.js - modal window)

modernizr.js - http://modernizr.com/

wow.js - animations during scroll site // http://mynameismatthieu.com/WOW/

slippry.min.js - slideshow // http://slippry.com/

jquery.nicescroll.js - smooth scrolling // https://github.com/inuyaksa/jquery.nicescroll