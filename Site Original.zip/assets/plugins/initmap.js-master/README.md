# Google Maps jQuery plugin

jQuery plugin for embedding Google Maps

## Getting Started
Download the [production version][min] or the [development version][max].

[min]: https://raw.github.com/jeromesmadja/initmap.js/master/dist/initmap.min.js
[max]: https://raw.github.com/jeromesmadja/initmap.js/master/dist/initmap.js

## Documentation
[See documentation here][documentation]

[documentation]: http://jeromesmadja.github.io/initmapjs/

## Release History
__1.1.0__ Added unsupported callback function on HTML5 geolocation, for older browsers  
__1.0.0__ Initial version
